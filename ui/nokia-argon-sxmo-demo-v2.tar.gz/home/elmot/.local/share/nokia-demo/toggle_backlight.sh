#!/bin/sh
export XDG_RUNTIME_DIR="${XDG_RUNTIME_DIR:-/run/user/$(id -u)}"
export WAYLAND_DISPLAY="${WAYLAND_DISPLAY:-wayland-1}"
cur=$(brightnessctl -d backlight get 2>/dev/null || echo 0)
if [ "$cur" -gt 0 ]; then
    brightnessctl -d backlight set 0 >/dev/null 2>&1
else
    wlopm --on "*" >/dev/null 2>&1 || true
    brightnessctl -d backlight set 100% >/dev/null 2>&1
fi
