#!/bin/sh
# configversion: 113bf453dd3310afff192d841089e5ac
if [ "$1" = "powerbutton_one" ]; then
    exec /home/elmot/.local/share/nokia-demo/toggle_backlight.sh
fi
exec /usr/share/sxmo/default_hooks/sxmo_hook_inputhandler.sh "$@"
