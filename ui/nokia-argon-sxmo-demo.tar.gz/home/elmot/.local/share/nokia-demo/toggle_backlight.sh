#!/bin/sh
cur=$(brightnessctl -d backlight get 2>/dev/null || echo 0)
if [ "$cur" -gt 0 ]; then
    brightnessctl -d backlight set 0 >/dev/null 2>&1
else
    brightnessctl -d backlight set 100% >/dev/null 2>&1
fi
